# Clerk Auth Implementation Tasks

- [ ] Install @clerk/nextjs
- [ ] Create .env.local + .env.example
- [ ] Create types/globals.d.ts (RBAC types)
- [ ] Create middleware.ts (route protection + RBAC)
- [ ] Create lib/clerk-appearance.ts
- [ ] Update app/globals.css (light theme design system)
- [ ] Update app/layout.tsx (ClerkProvider + fonts)
- [ ] Create components/auth-layout.tsx
- [ ] Create components/role-gate.tsx
- [ ] Create app/sign-in/[[...sign-in]]/page.tsx
- [ ] Create app/sign-up/[[...sign-up]]/page.tsx
- [ ] Create app/dashboard/layout.tsx
- [ ] Create app/dashboard/page.tsx
- [ ] Create app/admin/page.tsx
- [ ] Update app/page.tsx (landing page)
- [ ] Verify build
