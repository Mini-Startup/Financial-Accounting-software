# Clerk Authentication — Implementation Plan

## Background

Fresh Next.js 16.2.1 project with Tailwind CSS v4, TypeScript, and App Router. No existing auth, no additional packages beyond the defaults. Goal: integrate Clerk for full authentication including login, registration, OTP, password reset, RBAC, session management, and optional 2FA.

---

## User Review Required

> [!IMPORTANT]
> **Clerk API Keys** — You must create a Clerk application at [clerk.com](https://clerk.com) and provide:
> - `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY`
> - `CLERK_SECRET_KEY`
>
> Without these the app will not start.

> [!IMPORTANT]
> **Role Assignment** — Roles (`admin` / `client`) will be stored in Clerk's `publicMetadata`. You'll need to assign roles either:
> 1. Manually via Clerk Dashboard → Users → Edit metadata, OR
> 2. Via a Clerk webhook + API route (can be added later)
>
> Which approach do you want for MVP?

> [!WARNING]
> **Font Choice** — The default project ships with Geist / Geist Mono (system-ish fonts). Per your design rules, these are disallowed. I'll replace them with **Sora** (headings) + **DM Sans** (body) — a distinctive pairing that matches a financial/accounting aesthetic. Let me know if you prefer something else.

---

## Proposed Changes

### 1 · Package Installation

```bash
npm install @clerk/nextjs
```

Single dependency. Everything else (hooks, components, middleware) ships inside `@clerk/nextjs`.

---

### 2 · Environment & Config

#### [NEW] `.env.local`

```
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_REPLACE_ME
CLERK_SECRET_KEY=sk_test_REPLACE_ME
NEXT_PUBLIC_CLERK_SIGN_IN_URL=/sign-in
NEXT_PUBLIC_CLERK_SIGN_UP_URL=/sign-up
NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL=/dashboard
NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL=/dashboard
```

#### [NEW] `.env.example`

Copy of above with placeholder values for team reference.

---

### 3 · Design System (Globals + Tailwind)

#### [MODIFY] `app/globals.css`

Replace the default Tailwind config with a full dark-mode financial design system:

- CSS variables for color tokens (deep navy, teal accent, slate surfaces)
- Font imports for **Sora** + **DM Sans** via `@import url()`
- Layered gradient backgrounds, glassmorphism utilities
- Animation keyframes for page entry and micro-interactions

#### [MODIFY] `app/layout.tsx`

- Swap Geist fonts for **Sora** + **DM Sans**
- Wrap `{children}` with `<ClerkProvider>`
- Add metadata title/description for SEO

---

### 4 · Middleware (Route Protection + RBAC)

#### [NEW] `middleware.ts` (project root)

```
clerkMiddleware with:
  - Public routes: /sign-in(.*), /sign-up(.*), /
  - Protected routes: /dashboard(.*)
  - Admin routes: /admin(.*)  → redirects non-admin users
```

Uses `createRouteMatcher` and `auth.protect()` from the latest Clerk API.

---

### 5 · TypeScript Declarations

#### [NEW] `types/globals.d.ts`

Extend `CustomJwtSessionClaims` to type `metadata.role` for compile-time safety:

```ts
export {}
declare global {
  interface CustomJwtSessionClaims {
    metadata: { role?: "admin" | "client" }
  }
}
```

---

### 6 · Auth Pages (Custom UI)

#### [NEW] `app/sign-in/[[...sign-in]]/page.tsx`

- Centers the Clerk `<SignIn />` component
- Premium dark glassmorphic card wrapper
- Animated background with geometric patterns
- Custom `appearance` prop to theme Clerk's UI to match the design system
- Links to `/sign-up`

#### [NEW] `app/sign-up/[[...sign-up]]/page.tsx`

- Same premium layout as sign-in
- Uses `<SignUp />` component
- `fallbackRedirectUrl="/dashboard"`
- Links to `/sign-in`

---

### 7 · Protected Dashboard

#### [NEW] `app/dashboard/page.tsx`

- Protected route (middleware enforces auth)
- Displays user info from `currentUser()` (server component)
- Shows role badge (admin/client)
- `<UserButton />` for profile management
- Premium card-based layout with welcome message, quick stats placeholders

#### [NEW] `app/dashboard/layout.tsx`

- Dashboard shell with sidebar navigation skeleton
- Auth-aware header with `<UserButton />`

---

### 8 · Shared Components

#### [NEW] `components/auth-layout.tsx`

Shared layout wrapper for sign-in / sign-up pages with:
- Animated gradient background
- Glassmorphic card container
- Logo/branding area
- Responsive design

#### [NEW] `components/role-gate.tsx`

Client-side RBAC wrapper:
```tsx
<RoleGate allowedRole="admin">
  {/* Admin-only content */}
</RoleGate>
```

Uses `useUser()` to check `publicMetadata.role`.

---

### 9 · Admin Route Example

#### [NEW] `app/admin/page.tsx`

- Admin-only page protected by middleware RBAC
- Shows admin panel placeholder
- Demonstrates role-based content rendering

---

## File Tree (Final)

```
├── .env.local                              [NEW]
├── .env.example                            [NEW]
├── middleware.ts                            [NEW]
├── types/
│   └── globals.d.ts                        [NEW]
├── components/
│   ├── auth-layout.tsx                     [NEW]
│   └── role-gate.tsx                       [NEW]
├── app/
│   ├── globals.css                         [MODIFY]
│   ├── layout.tsx                          [MODIFY]
│   ├── page.tsx                            [MODIFY — update landing]
│   ├── sign-in/
│   │   └── [[...sign-in]]/
│   │       └── page.tsx                    [NEW]
│   ├── sign-up/
│   │   └── [[...sign-up]]/
│   │       └── page.tsx                    [NEW]
│   ├── dashboard/
│   │   ├── layout.tsx                      [NEW]
│   │   └── page.tsx                        [NEW]
│   └── admin/
│       └── page.tsx                        [NEW]
```

---

## Open Questions

> [!IMPORTANT]
> 1. **Do you have the Clerk API keys ready?** I need them to create `.env.local` with real values so the app actually runs.
> 2. **Role assignment approach** — Manual via dashboard, or should I add a webhook/API route for automated role sync?
> 3. **Landing page** — Should `app/page.tsx` (the `/` route) be public with sign-in/sign-up CTAs, or should it redirect to `/dashboard` for authenticated users?
> 4. **Color direction** — I'm going with a dark navy + teal accent financial theme. Any preference for a different palette?

---

## Verification Plan

### Automated Tests
```bash
npm run build          # Ensure no TypeScript or build errors
npm run lint           # ESLint passes
```

### Browser Verification
1. Navigate to `/` → should see public landing page
2. Navigate to `/dashboard` → should redirect to `/sign-in`
3. Sign up → should redirect to `/dashboard`
4. Sign in → should redirect to `/dashboard`
5. Sign out → should redirect to `/sign-in`
6. Navigate to `/admin` as non-admin → should redirect to `/`
7. UI check → dark theme, glassmorphism, animations all rendering correctly

### Manual Verification
- Clerk Dashboard: verify user creation, metadata, session activity
- Test OTP flow if email verification is enabled in Clerk settings
- Test password reset via Clerk's built-in flow
